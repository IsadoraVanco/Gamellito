/**
 * Components that encapsulate media.
 */
package uk.co.caprica.vlcj.media;
