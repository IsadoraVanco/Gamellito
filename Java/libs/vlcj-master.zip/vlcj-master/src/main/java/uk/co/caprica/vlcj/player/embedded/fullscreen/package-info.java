/**
 * Events relating to media.
 */
package uk.co.caprica.vlcj.player.embedded.fullscreen;
