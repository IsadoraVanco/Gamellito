/**
 * Provides various support classes, not generally useful for client applications.
 */
package uk.co.caprica.vlcj.support;
