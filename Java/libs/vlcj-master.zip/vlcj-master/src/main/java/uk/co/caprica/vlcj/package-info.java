/**
 * Java framework for the VLC media player.
 * <p>
 * Most applications should start with the {@link uk.co.caprica.vlcj.factory.MediaPlayerFactory}.
 */
package uk.co.caprica.vlcj;
