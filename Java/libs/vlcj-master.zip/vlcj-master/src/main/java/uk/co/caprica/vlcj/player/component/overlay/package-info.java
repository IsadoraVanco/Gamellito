/**
 * Provides higher-level components used to create overlays for use with embedded media player components.
 */
package uk.co.caprica.vlcj.player.component.overlay;
