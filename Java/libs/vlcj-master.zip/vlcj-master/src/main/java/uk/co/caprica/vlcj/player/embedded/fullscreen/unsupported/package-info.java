/**
 * A do-nothing full-screen strategy implementation to explicitly and completely disable full-screen support.
 */
package uk.co.caprica.vlcj.player.embedded.fullscreen.unsupported;
