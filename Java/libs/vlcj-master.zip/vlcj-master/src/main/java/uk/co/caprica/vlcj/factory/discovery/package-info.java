/**
 * Provides components that can be used to automatically discover the location of the LibVLC native libraries in the
 * absence of proper run-time environment configuration.
 */
package uk.co.caprica.vlcj.factory.discovery;
