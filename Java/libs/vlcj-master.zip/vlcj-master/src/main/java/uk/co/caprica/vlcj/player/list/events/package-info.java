/**
 * Media list player events.
 */
package uk.co.caprica.vlcj.player.list.events;
