/**
 * Provides the classes necessary to create user interface components that
 * render native video.
 */
package uk.co.caprica.vlcj.player.embedded.videosurface;
