/**
 * Provides default buffer format implementations.
 */
package uk.co.caprica.vlcj.player.embedded.videosurface.callback.format;
