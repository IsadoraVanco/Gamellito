/**
 * Native full-screen strategy for Windows.
 */
package uk.co.caprica.vlcj.player.embedded.fullscreen.windows;
