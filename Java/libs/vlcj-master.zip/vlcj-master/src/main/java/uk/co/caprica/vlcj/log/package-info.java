/**
 * Native LibVLC log component.
 */
package uk.co.caprica.vlcj.log;
