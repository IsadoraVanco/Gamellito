/**
 * Components used by the {@link uk.co.caprica.vlcj.player.component.CallbackMediaPlayerComponent}.
 * <p>
 * Provides implementations of "painter" components used to render video frames.
 */
package uk.co.caprica.vlcj.player.component.callback;
