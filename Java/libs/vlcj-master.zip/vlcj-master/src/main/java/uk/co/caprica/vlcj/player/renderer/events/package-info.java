/**
 * Factory for components that encapsulate native renderer discoverer events.
 */
package uk.co.caprica.vlcj.player.renderer.events;
