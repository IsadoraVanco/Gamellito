/**
 * Full-screen strategy that uses the standard JDK approach.
 * <p>
 * This strategy is <em>not</em> recommended.
 */
package uk.co.caprica.vlcj.player.embedded.fullscreen.exclusivemode;
