/**
 * Provides the classes necessary to implement video engine rendering.
 */
package uk.co.caprica.vlcj.player.embedded.videosurface.videoengine;
