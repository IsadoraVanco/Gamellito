/**
 * Full-screen strategy implementation that picks the best available depending on the run-time operating system.
 */
package uk.co.caprica.vlcj.player.embedded.videosurface.callback;
