/**
 * Components used for media that is provided by native media callback functions.
 */
package uk.co.caprica.vlcj.media.callback;
