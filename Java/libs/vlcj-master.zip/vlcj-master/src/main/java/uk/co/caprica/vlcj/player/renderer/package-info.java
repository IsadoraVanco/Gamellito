/**
 * Provides components that can be used to automatically discover alternate media "renderers" like Chromecast.
 */
package uk.co.caprica.vlcj.player.renderer;
