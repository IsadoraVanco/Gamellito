/**
 * Native full-screen strategy for the X Window System.
 */
package uk.co.caprica.vlcj.player.embedded.fullscreen.x;
