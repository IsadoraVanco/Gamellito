/**
 * Components that implement full-screen behaviour for media players.
 */
package uk.co.caprica.vlcj.player.base.events;
