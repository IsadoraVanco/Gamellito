/**
 * Base implementation for components that use a native event manager, and components that support provide support for
 * native event handling generally.
 * <p>
 * <em>This package is <strong>not</strong> public API.</em>
 */
package uk.co.caprica.vlcj.support.eventmanager;
