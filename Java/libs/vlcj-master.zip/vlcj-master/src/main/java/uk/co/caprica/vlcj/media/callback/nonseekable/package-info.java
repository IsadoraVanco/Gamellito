/**
 * Components that implement non-seekable media, e.g. just about all Java input streams.
 */
package uk.co.caprica.vlcj.media.callback.nonseekable;
