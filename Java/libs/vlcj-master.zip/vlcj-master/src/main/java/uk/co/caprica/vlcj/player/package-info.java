/**
 * This is the main package for media player components, sub-packages provide the classes necessary to create and
 * control native media players and associated resources.
 */
package uk.co.caprica.vlcj.player;
