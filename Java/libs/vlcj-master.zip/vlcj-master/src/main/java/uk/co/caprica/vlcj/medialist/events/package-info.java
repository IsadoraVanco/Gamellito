/**
 * Media list events.
 */
package uk.co.caprica.vlcj.medialist.events;
